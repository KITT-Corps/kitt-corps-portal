import { motion } from 'motion/react';
import { Database, GitBranch, Terminal, Shield, Zap, RefreshCw, Cpu } from 'lucide-react';

interface HeroProps {
  onScrollToMerge: () => void;
  onScrollToNodes: () => void;
  onScrollToInstall: () => void;
}

export default function HeroSection({ onScrollToMerge, onScrollToNodes, onScrollToInstall }: HeroProps) {
  return (
    <div className="relative overflow-hidden border-b border-slate-800 bg-slate-950/80 pt-16 pb-20 md:pb-28">
      {/* Dynamic Grid Overlay */}
      <div className="grid-lines absolute inset-0 opacity-40 pointer-events-none" />
      
      {/* Decorative Blur Spheres */}
      <div className="absolute top-1/4 left-1/3 -translate-x-1/2 -translate-y-1/2 w-80 h-80 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-1/4 w-96 h-96 rounded-full bg-purple-500/10 blur-3xl pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Organization Tag */}
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-cyan-500/20 bg-cyan-950/30 text-xs font-mono tracking-widest text-cyan-400 uppercase mb-8"
        >
          <Cpu className="w-3.5 h-3.5 animate-spin" style={{ animationDuration: '6s' }} />
          <span>KITT Corps // Research & Development</span>
        </motion.div>

        {/* Hero Title */}
        <motion.h1 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-4xl sm:text-6xl font-bold tracking-tight text-white mb-6"
        >
          Centralized Database{" "}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-emerald-400 to-amber-400">
            Orchestration & Fusion
          </span>
        </motion.h1>

        {/* Hero Subtitle */}
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="max-w-2xl mx-auto text-lg text-slate-400 font-sans tracking-wide leading-relaxed mb-10"
        >
          Stop wrestling with heterogeneous data pipelines. KITT Corps provides developer-first systems 
          to merge multiple data sources seamlessly into unified relational repositories for single-point intelligence.
        </motion.p>

        {/* CTA Actions */}
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="flex flex-wrap justify-center gap-4 mb-16"
        >
          <button
            onClick={onScrollToMerge}
            className="group relative px-6 py-3.5 rounded-lg font-mono text-sm font-semibold tracking-wide border border-cyan-400 bg-cyan-400 text-slate-950 hover:bg-transparent hover:text-cyan-400 transition-all duration-300 glow-cyan cursor-pointer"
          >
            <span className="flex items-center gap-2">
              <Zap className="w-4 h-4 transition-transform group-hover:scale-125" />
              Run Data-Mate Engine
            </span>
          </button>
          
          <button
            onClick={onScrollToNodes}
            className="px-6 py-3.5 rounded-lg font-mono text-sm font-medium border border-slate-800 bg-slate-900/60 text-slate-300 hover:border-slate-700 hover:text-white transition-all cursor-pointer"
          >
            <span className="flex items-center gap-2">
              <GitBranch className="w-4 h-4 text-purple-400" />
              Interactive Node Visualizer
            </span>
          </button>

          <button
            onClick={onScrollToInstall}
            className="px-6 py-3.5 rounded-lg font-mono text-sm font-medium text-slate-400 hover:text-white transition-all cursor-pointer"
          >
            <span className="flex items-center gap-2 hover:underline">
              <Terminal className="w-4 h-4 text-emerald-400" />
              Installation & API Docs
            </span>
          </button>
        </motion.div>

        {/* Feature Cards Grid */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="grid md:grid-cols-3 gap-6 text-left"
        >
          <div className="p-6 rounded-xl border border-slate-800 bg-slate-900/40 backdrop-blur-sm">
            <div className="p-3 w-fit rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 mb-4">
              <Database className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold font-sans text-slate-200 mb-2">Heterogeneous Ingestion</h3>
            <p className="text-sm text-slate-400 leading-relaxed">
              Consolidate structured tables from SQL instances and nested document structures from MongoDB databases into an organized schema.
            </p>
          </div>

          <div className="p-6 rounded-xl border border-slate-800 bg-slate-900/40 backdrop-blur-sm">
            <div className="p-3 w-fit rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 mb-4">
              <RefreshCw className="w-5 h-5 animate-spin" style={{ animationDuration: '8s' }} />
            </div>
            <h3 className="text-lg font-bold font-sans text-slate-200 mb-2">Automated Synchronization</h3>
            <p className="text-sm text-slate-400 leading-relaxed">
              Automate schema parsing and type conversions to direct pipelines without manual scripting. Let Data-Mate build the central database schema.
            </p>
          </div>

          <div className="p-6 rounded-xl border border-slate-800 bg-slate-900/40 backdrop-blur-sm">
            <div className="p-3 w-fit rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400 mb-4">
              <Shield className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold font-sans text-slate-200 mb-2">Zero-Trust Local Control</h3>
            <p className="text-sm text-slate-400 leading-relaxed">
              Your credentials are yours. Fully decentralized, command-line operable, or custom-hosted with DataMateWeb’s Python-Flask administrator portal.
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
