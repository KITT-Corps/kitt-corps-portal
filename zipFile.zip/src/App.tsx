import { useRef } from 'react';
import HeroSection from './components/HeroSection';
import ProjectDetails from './components/ProjectDetails';
import DatabaseMerger from './components/DatabaseMerger';
import NodeVisualizer from './components/NodeVisualizer';
import { GitBranch, Mail, Terminal, Database, Shield, Zap, Cpu, Code2 } from 'lucide-react';

export default function App() {
  const scrollToId = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="min-h-screen bg-[#070b13] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      
      {/* Cinematic Glowing Header Grid Overlay */}
      <div className="absolute top-0 inset-x-0 h-44 bg-gradient-to-b from-cyan-950/20 to-transparent pointer-events-none" />

      {/* Developer Top Header Navigation */}
      <header className="sticky top-0 z-50 backdrop-blur-md bg-slate-950/80 border-b border-slate-900/60 transition-all">
        <div id="navbar-container" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div 
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} 
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="p-2 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 group-hover:scale-105 transition-transform">
              <Cpu className="w-5 h-5" />
            </div>
            <span className="text-xl font-bold font-sans tracking-tight text-white flex items-center gap-1.5">
              KITT <span className="text-cyan-400 font-mono text-sm tracking-widest uppercase">CORPS</span>
            </span>
          </div>

          {/* Quick-links selection */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-mono text-slate-400">
            <button
              onClick={() => scrollToId('installation-cli')}
              className="hover:text-cyan-400 transition-colors cursor-pointer"
            >
              Documentation
            </button>
            <button
              onClick={() => scrollToId('database-merger')}
              className="hover:text-cyan-400 transition-colors cursor-pointer"
            >
              Data-Mate Engine
            </button>
            <button
              onClick={() => scrollToId('node-visualizer')}
              className="hover:text-cyan-400 transition-colors cursor-pointer"
            >
              Topology Nodes
            </button>
          </nav>

          {/* Org Github Shortcut */}
          <div className="flex items-center gap-3">
            <a
              href="https://github.com/KITT-Corps"
              target="_blank"
              rel="noreferrer"
              className="px-3.5 py-1.5 rounded-lg border border-slate-800 bg-slate-950 text-xs font-mono text-slate-300 hover:text-white hover:border-slate-700 transition-all inline-flex items-center gap-2"
            >
              <GitBranch className="w-3.5 h-3.5 text-purple-400 animate-pulse" />
              <span>GitHub Org</span>
            </a>
          </div>
        </div>
      </header>

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* 1. Hero Presenter */}
        <HeroSection 
          onScrollToMerge={() => scrollToId('database-merger')}
          onScrollToNodes={() => scrollToId('node-visualizer')}
          onScrollToInstall={() => scrollToId('installation-cli')}
        />

        {/* 2. Primary Documentation & Install CLI details (Data-Mate vs DataMateWeb) */}
        <ProjectDetails />

        {/* 3. Interactive Data-Mate Consolidation Playground */}
        <DatabaseMerger />

        {/* 4. Interactive DataMateWeb Topology Grid Matrix */}
        <NodeVisualizer />
      </main>

      {/* Developer footer signature block */}
      <footer className="bg-slate-950 border-t border-slate-900 py-12 text-sm text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid md:grid-cols-4 gap-8">
          
          {/* Identity Info */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="p-1.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                <Cpu className="w-4 h-4" />
              </div>
              <span className="text-md font-bold text-white">KITT Corps</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed font-sans max-w-sm">
              Simplifying the bridge between diverse databases (SQL & document schemas). 
              Engineered for data scientists, developers, and analytics engineers seeking single-source supremacy.
            </p>
            <p className="text-[10px] font-mono text-slate-600">
              &copy; {new Date().getFullYear()} KITT-Corps. MIT License.
            </p>
          </div>

          {/* Core Projects */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono tracking-wider uppercase text-slate-300 font-bold">REPOSITORIES</h4>
            <ul className="space-y-2 text-xs font-mono list-none p-0 m-0">
              <li>
                <a 
                  href="https://github.com/KITT-Corps/Data-Mate" 
                  target="_blank" 
                  rel="noreferrer" 
                  className="hover:text-cyan-400 transition-colors block"
                >
                  ↳ Data-Mate (Core API)
                </a>
              </li>
              <li>
                <a 
                  href="https://github.com/Chaos-Corps/DataMateWeb" 
                  target="_blank" 
                  rel="noreferrer" 
                  className="hover:text-purple-400 transition-colors block"
                >
                  ↳ DataMateWeb (Dashboard)
                </a>
              </li>
            </ul>
          </div>

          {/* Org & Credits */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono tracking-wider uppercase text-slate-300 font-bold">ENGINEERS & TEAM</h4>
            <div className="text-xs space-y-1 bg-slate-900/40 p-3 rounded-lg border border-slate-905 font-mono text-slate-400">
              <div className="text-slate-200">Krishna Priyatham Potluri</div>
              <div className="text-[10px]">Lead Creator & Designer</div>
              <a 
                href="mailto:kittu.priyatham@gmail.com" 
                className="text-[10px] text-cyan-400 hover:underline inline-flex items-center gap-1 mt-1.5"
              >
                <Mail className="w-3 h-3" /> Contact Hub
              </a>
            </div>
          </div>
        </div>
      </footer>

    </div>
  );
}
